package com.example.aula2_atividade1;


import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Turma {

    @SerializedName("estudantes")
    @Expose
    private List<Estudante> estudantes;

    /**
     * No args constructor for use in serialization
     *
     */
    public Turma() {
    }

    /**
     *
     * @param estudantes
     */
    public Turma(List<Estudante> estudantes) {
        super();
        this.estudantes = estudantes;
    }

    public List<Estudante> getEstudantes() {
        return estudantes;
    }

    public void setEstudantes(List<Estudante> estudantes) {
        this.estudantes = estudantes;
    }

}
package com.example.aula2_atividade1;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.MalformedInputException;

public class Conexao {

    private String URI;
    private InputStream inputStream;

    public Conexao(String URI){
        this.URI=URI;
        inputStream=null;
    }

    public InputStream get(){
        try {
            URL url =new URL(this.URI);
            HttpURLConnection conexao = (HttpURLConnection)
                    url.openConnection();
            conexao.setRequestMethod("GET");
            this.inputStream = new BufferedInputStream(conexao.getInputStream());
            return this.inputStream;
        }catch (MalformedInputException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
        this.inputStream = null;
        return this.inputStream;
    }

    public String getURI() {
        return URI;
    }

    public void setURI(String URI) {
        this.URI = URI;
    }

    public InputStream getInputStream() {
        return inputStream;
    }

    public void setInputStream(InputStream inputStream) {
        this.inputStream = inputStream;
    }
}

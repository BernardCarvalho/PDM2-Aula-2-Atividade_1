package com.example.aula2_atividade1;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Estudante {

    @SerializedName("nome")
    @Expose
    private String nome;
    @SerializedName("ano_nascimento")
    @Expose
    private Integer anoNascimento;
    @SerializedName("notas")
    @Expose
    private List<Nota> notas;

    /**
     * No args constructor for use in serialization
     *
     */
    public Estudante() {
    }

    /**
     *
     * @param anoNascimento
     * @param notas
     * @param nome
     */
    public Estudante(String nome, Integer anoNascimento, List<Nota> notas) {
        super();
        this.nome = nome;
        this.anoNascimento = anoNascimento;
        this.notas = notas;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getAnoNascimento() {
        return anoNascimento;
    }

    public void setAnoNascimento(Integer anoNascimento) {
        this.anoNascimento = anoNascimento;
    }

    public List<Nota> getNotas() {
        return notas;
    }

    public void setNotas(List<Nota> notas) {
        this.notas = notas;
    }

    public Double getMedia(){
        int soma_notas=0;
        if(notas.size()==0)
            return null;
        for(int i=0; i<notas.size();i++){
            soma_notas+=notas.get(i).getValor();
        }
        return Double.valueOf(soma_notas/notas.size());
    }

    public boolean isAprovado(){
        if(this.getMedia()<6)
            return false;
        return true;
    }

    public int getIdade(){
        return LocalDate.now().getYear() - anoNascimento.intValue();
    }

    @Override
    public String toString() {
        return
                "Nome do Estudante: '"+this.getNome()+"'\n"+
                "Idade do Estudante: '"+this.getIdade()+"'\n"+
                "Media do Estudante: '"+this.getMedia()+"'\n"+
                "Situacao do Estudante: '"+(this.isAprovado()?"Aprovado":"Reprovado")+"'\n"
                ;
    }
}
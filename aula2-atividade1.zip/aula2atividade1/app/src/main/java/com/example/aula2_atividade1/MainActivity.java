package com.example.aula2_atividade1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.JsonReader;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private static final String URI = "https://my-json-server.typicode.com/BernardCarvalho/PDM2-Aula_2-Atividade_1/db";
    private String stringJSON="";
    private boolean done = false;
    private Handler handler;
    private Turma turma;

    private ArrayAdapter<Estudante> adapter;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.lista);
        Looper looper = getMainLooper();
        handler = Handler.createAsync(looper);
        DownloadJson();




    }

    private void DownloadJson() {

        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                Conexao conexao = new Conexao(URI);
                conexao.get();
                if(conexao.getInputStream()==null)
                    System.out.println("ERRO, INPUT STREAM É NULO");
                String a = new ConexaoReader().converter(conexao.getInputStream());
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                         done = true;
                         stringJSON=a;
                         convertJSONIntoObject();
                    }
                });
            }
        });
        t2.start();
    }

    private void convertJSONIntoObject() {
        /*System.out.println(stringJSON);*/
        Gson gson = new Gson();
        Type type = new TypeToken<Turma>(){}.getType();
        try{
            turma = gson.fromJson(stringJSON,type);

            draw();

            /*//substituir por listView
            StringBuilder sb = new StringBuilder();

            for(int i=0; i<turma.getEstudantes().size();i++){
                sb.append(turma.getEstudantes().get(i).getNome()+"\n");
            }
            System.out.println(sb.toString());
            //substituir por listView*/
        } catch (JsonSyntaxException e) {
            throw new RuntimeException(e);
        }
       /* Gson gson = new Gson();
        Type type = new TypeToken<List<Estudante>>(){}.getType();
        try{
            estudantes = gson.fromJson(stringJSON,type);

            StringBuilder sb = new StringBuilder();
            for(int i=0; i<estudantes.size();i++){
                sb.append(estudantes.get(i).toString()+"\n");
            }
            System.out.println(sb.toString());
            System.out.println("------------");
            System.out.println(stringJSON);
            //trabalhar com adapters para mostrar o sb.toString()
        }catch(Exception e){
            System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
            e.printStackTrace();
        }*/

    }

    private void draw() {
        adapter = new ArrayAdapter<Estudante>(this, android.R.layout.simple_list_item_1, turma.getEstudantes());
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((adapterView, view, i, l) -> {
            StringBuilder sb = new StringBuilder();
            sb.append("Notas:\n");
            for(int j=0; j<adapter.getItem(i).getNotas().size();j++)
                sb.append("Nota ["+j+"]: "+adapter.getItem(i).getNotas().get(j).getValor()+"\n");
            AlertDialog alertDialog = new AlertDialog.Builder(view.getContext())
                    .setTitle(adapter.getItem(i).getNome())
                    .setMessage(sb.toString())
                    .create();
            alertDialog.show();
        });
    }
}
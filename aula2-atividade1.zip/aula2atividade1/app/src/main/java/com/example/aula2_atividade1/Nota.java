package com.example.aula2_atividade1;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Nota {

    @SerializedName("valor")
    @Expose
    private Integer valor;

    /**
     * No args constructor for use in serialization
     *
     */
    public Nota() {
    }

    /**
     *
     * @param valor
     */
    public Nota(Integer valor) {
        super();
        this.valor = valor;
    }

    public Integer getValor() {
        return valor;
    }

    public void setValor(Integer valor) {
        this.valor = valor;
    }

}